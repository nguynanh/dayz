DAYZ MORSE DECODER - ANDROID

Dự án Android bọc file HTML gốc trong Android WebView.
Ứng dụng chạy offline, không yêu cầu quyền Internet.

TẠO APK CHỈ BẰNG ĐIỆN THOẠI SAMSUNG (KHÔNG CẦN ANDROID STUDIO):
1. Giải nén ZIP trên điện thoại.
2. Tạo tài khoản GitHub tại https://github.com/signup (nếu chưa có).
3. Trên GitHub, tạo repository mới tên DayZ-Morse-Decoder, nhánh mặc định main.
4. Tải toàn bộ nội dung dự án đã giải nén lên repository, giữ nguyên cấu trúc thư mục.
   Lưu ý phải tải cả thư mục ẩn .github/workflows/build-apk.yml.
   Nếu trình duyệt không cho tải thư mục ẩn, vào repository > Add file > Create new file,
   đặt tên file là .github/workflows/build-apk.yml rồi dán nội dung workflow có sẵn
   trong ZIP (mở file bằng trình soạn thảo văn bản).
5. Mở tab Actions của repository. Nếu GitHub yêu cầu, nhấn "I understand my workflows,
   go ahead and enable them".
6. Chọn workflow "Build DayZ Morse Decoder APK" > Run workflow > Run workflow.
   Hoặc mỗi lần push commit lên nhánh main, workflow tự chạy.
7. Chờ workflow hoàn tất với dấu tick xanh. Mở lần chạy đó, kéo xuống phần Artifacts,
   nhấn DayZ-Morse-Decoder-APK để tải ZIP chứa app-debug.apk.
8. Mở ZIP vừa tải bằng Tệp của bạn, giải nén app-debug.apk.
9. Nhấn app-debug.apk để cài. Nếu Android chặn, vào Cài đặt > Bảo mật và quyền riêng tư
   (hoặc Sinh trắc học và bảo mật) > Cài đặt ứng dụng không rõ nguồn gốc,
   cho phép Chrome hoặc Tệp của bạn, rồi thử cài lại.

WORKFLOW:
- File: .github/workflows/build-apk.yml
- Dùng GitHub Actions, Java 17 và Gradle 8.9.
- Tạo APK debug và lưu artifact trong 14 ngày.

THÔNG TIN:
- Tên ứng dụng: DayZ Morse Decoder
- Application ID: com.dayz.morsedecoder
- Android tối thiểu: Android 6.0 (API 23)
- Không cần Internet khi sử dụng.
- HTML gốc: app/src/main/assets/index.html
